package models;

public class pet {
    public long id;
    public String name;
    public String status;

    public pet(long id, String name, String status) 
    {
        this.id = id;
        this.name = name;
        this.status = status;
    }
}