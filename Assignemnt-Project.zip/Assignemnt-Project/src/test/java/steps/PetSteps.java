package steps;

import io.restassured.RestAssured;
import io.restassured.response.Response;
import io.cucumber.java.en.*;
import models.pet;

import static org.hamcrest.Matchers.*;

public class PetSteps {
    private Response response;
    private final String BASE_URL = "https://petstore.swagger.io/v2";

    pet testPet = new pet(9223372, "doggie", "available");

    @Given("I create a new pet")
    public void createPet() {
        response = RestAssured.given()
                .contentType("application/json")
                .body(testPet)
                .when()
                .post(BASE_URL + "/pet");
        response.then().statusCode(200);
    }

    @When("I retrieve the pet by ID")
    public void getPet() {
        response = RestAssured.given()
                .when()
                .get(BASE_URL + "/pet/" + testPet.id);
    }

    @Then("The pet name should be returned")
    public void verifyPet() {
        response.then()
                .statusCode(200)
                .body("name", equalTo(testPet.name));
    }

    @And("I delete the pet")
    public void deletePet() {
        response = RestAssured.given()
                .when()
                .delete(BASE_URL + "/pet/" + testPet.id);
        response.then().statusCode(200);
    }
}
